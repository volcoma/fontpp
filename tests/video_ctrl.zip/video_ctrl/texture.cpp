#include "texture.h"

#include "platform.h"
#include "renderer.h"
#include "surface.h"

#define GL_GLEXT_PROTOTYPES // enable GLEXT framebuffer

#include <SDL2/SDL_opengl.h>
#include <GL/glx.h>

#ifdef HAS_GLI_LIB
#include <gli/gli.hpp>
#endif

#include "logger.h"
#include <sstream>

namespace video_ctrl
{
    namespace
    {
    #ifdef EGT_DEVELOP
    void gl_clear_error()
    {
        while(glGetError() != GL_NO_ERROR)
            ;
    }

    void gl_log_call(const char* function, const char* file, int line)
    {
        while(GLenum error = glGetError())
        {
            std::stringstream s;
            s << "[OpenGL Error] (" << error << "): " << function << " " << file << ":" << line << "\n";
            log(s.str());
        }
    }

    #define gl_call(x)                                                                                           \
        gl_clear_error();                                                                                        \
        x;                                                                                                       \
        gl_log_call(#x, __FILE__, __LINE__)
    #else

    #define gl_call(x) x

    #endif

        template<typename T>
        T get_func(const char *func_name)
        {
            return reinterpret_cast<T>(glXGetProcAddress(reinterpret_cast<const GLubyte*>(func_name)));
        }

        auto _glXCreatePixmap = get_func<PFNGLXCREATEPIXMAPPROC>("glXCreatePixmap");
        auto _glXDestroyPixmap = get_func<PFNGLXCREATEPIXMAPPROC>("glXDestroyPixmap");
        auto _glXBindTexImageEXT = get_func<PFNGLXBINDTEXIMAGEEXTPROC>("glXBindTexImageEXT");
        auto _glXReleaseTexImageEXT = get_func<PFNGLXRELEASETEXIMAGEEXTPROC>("glXReleaseTexImageEXT");
    }

    texture::texture(const renderer &rend) noexcept
        : rend_(rend)
    {
    }

    /// Texture constructor
    ///     @param rend - renderer interface
    ///     @param width - texture width in pixels
    ///     @param height - texture height in pixels
    ///     @param pixel_type - type of pixel data
    ///     @param format type - texture usage type
    texture::texture(const renderer &rend, int width, int height, pix_type pixel_type, texture::format_type format_type)
        : rend_(rend)
        , pixel_type_(pixel_type)
        , format_type_(format_type)
        , rect_(0,0, width, height)
    {
        if (!rend_.set_current_context())
        {
            throw video_ctrl::exception("Cannot set current context!");
        }

        if (texture::format_type::pixmap == format_type_)
        {
            // We're building a xpixmap (X11 optimized routines)
            rend_.reset_texture(0);
            auto xdisplay = rend_.win_.get_xdisplay();
            auto drawable = rend_.win_.get_drawable();
            XWindowAttributes wattr {};
            wattr.depth = 8;
            XGetWindowAttributes(xdisplay, drawable, &wattr);
            xpixmap_ = XCreatePixmap(xdisplay, drawable, static_cast<uint32_t> (width), static_cast<uint32_t> (height),
                                     static_cast<uint32_t> (wattr.depth));

            if (xpixmap_ == 0)
            {
                throw video_ctrl::exception("Cannot create xpixmap buffer");
            }

            std::vector<int> attributes {
                                            GLX_DRAWABLE_TYPE,      GLX_PIXMAP_BIT,
                                            GLX_DOUBLEBUFFER,       GL_TRUE,
                                            GLX_RENDER_TYPE,        GLX_RGBA_BIT,
                                            GLX_X_RENDERABLE,       GL_TRUE,
                                            GLX_Y_INVERTED_EXT,     GL_TRUE,
                                            GLX_RED_SIZE,           8,
                                            GLX_GREEN_SIZE,         8,
                                            GLX_BLUE_SIZE,          8,
                                            GLX_DEPTH_SIZE,         1,
                                        };

            if (pix_type::rgba == pixel_type_)
            {
                attributes.push_back(GLX_ALPHA_SIZE);
                attributes.push_back(8);
                attributes.push_back(GLX_BIND_TO_TEXTURE_RGBA_EXT);
                attributes.push_back(GL_TRUE);
            }
            else
            {
                attributes.push_back(GLX_BIND_TO_TEXTURE_RGB_EXT);
                attributes.push_back(GL_TRUE);
            }
            
            attributes.push_back(GL_NONE);

            int n_fbconfig_attrs {};
            auto fbconfig = glXChooseFBConfig(xdisplay, DefaultScreen(xdisplay), attributes.data(), &n_fbconfig_attrs);
            if (!fbconfig)
            {
                XFreePixmap(xdisplay, xpixmap_);
                xpixmap_ = 0;
                throw video_ctrl::exception("Cannot get FBConfig.");
            }

            std::vector<int> pixmap_attrs {
                                              GLX_TEXTURE_TARGET_EXT, GLX_TEXTURE_2D_EXT,
                                              GLX_MIPMAP_TEXTURE_EXT, GL_FALSE
                                          };

            pixmap_attrs.push_back(GLX_TEXTURE_FORMAT_EXT);
            pixmap_attrs.push_back(pix_type::rgba == pixel_type_ ? GLX_TEXTURE_FORMAT_RGBA_EXT : GLX_TEXTURE_FORMAT_RGB_EXT);
            pixmap_attrs.push_back(GL_NONE);

            glx_pixmap_ = _glXCreatePixmap(xdisplay, fbconfig[0], xpixmap_, pixmap_attrs.data());

            if (glx_pixmap_ == 0)
            {
                XFreePixmap(xdisplay, xpixmap_);
                xpixmap_ = 0;
                throw video_ctrl::exception("Cannot create glXCreatePixmap.");
            }
        }

        // Generate the OGL texture ID
        int pixel_format = get_opengl_pixel_format(pixel_type);
        gl_call(glGenTextures(1, &texture_));
        rend_.set_texture(texture_, 0, wrap_type::wrap_clamp, interpolation_type::interpolate_linear);

        if (!check_for_error("texture"))
        {
            throw video_ctrl::exception("Cannot create texture. Parameters w: " + std::to_string(width) + ", h: " +
                                            std::to_string(height));
        }

        // Upload data to VRAM
        if (texture::format_type::target == format_type_)
        {
            gl_call(glTexImage2D(GL_TEXTURE_2D, 0, pixel_format, width, height, 0, static_cast<GLenum> (pixel_format), GL_UNSIGNED_BYTE, nullptr));
        }
        else if (texture::format_type::streaming == format_type_)
        {
            gl_call(glTexImage2D(GL_TEXTURE_2D, 0, pixel_format, width, height, 0, static_cast<GLenum> (pixel_format), GL_UNSIGNED_BYTE, nullptr));

            // We're building a framebuffer object
            gl_call(glGenFramebuffers(1, &fbo_));
            gl_call(glBindFramebuffer(GL_FRAMEBUFFER_EXT, fbo_));
            gl_call(glFramebufferTexture2D(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_2D, texture_, 0));

            GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER_EXT);
            gl_call(glBindFramebuffer(GL_FRAMEBUFFER_EXT, 0));
            if(status != GL_FRAMEBUFFER_COMPLETE_EXT)
            {
                throw video_ctrl::exception("Cannot create FBO. GL ERROR CODE: " + std::to_string(status));
            }
        }

        rend_.reset_texture(0);
    }

    /// Texture constructor from a surface
    ///     @param rend - renderer interface
    ///     @param surface - the surface to copy pixels from
    texture::texture(const renderer &rend, const surface &surface)
        : rend_(rend)
        , rect_(0, 0, surface.get_width(), surface.get_height())
    {
        if (!create_from_surface(surface))
        {
            throw video_ctrl::exception("Cannot create texture from surface.");
        }
    }

    texture::~texture()
    {
        if (glx_pixmap_ > 0)
        {
            // Destroy glxpixmap
            glXDestroyGLXPixmap(rend_.win_.get_xdisplay(), glx_pixmap_);
            glx_pixmap_ = 0;
        }

        if (xpixmap_ > 0)
        {
            // Destroy xpixmap
            XFreePixmap(rend_.win_.get_xdisplay(), xpixmap_);
            xpixmap_ = 0;
        }

        if (fbo_ > 0)
        {
            // Destroy FBO
            glDeleteFramebuffers(1, &fbo_);
            fbo_ = 0;
        }
        
        if (texture_ > 0)
        {
            // Destroy texture
            gl_call(glDeleteTextures(1, &texture_));
            texture_ = 0;
        }
    }

    /// Clear the texture. Works only for FBO textures
    ///     @param color - color to clear to
    ///     @return true on success
    bool texture::clear(const color &color)
    {
        if (format_type_ != format_type::streaming)
        {
            return false;
        }

        rend_.clear_fbo(fbo_, color);
        return true;
    }

    /// Load from a file
    ///     @param path - the filename
    ///     @return true on success
    bool texture::load_from_file(const std::string &path) noexcept
    {
        try
        {
            surface surf(path);

            if (!create_from_surface(surf))
            {
                return false;
            }

            rect_.w = surf.get_width();
            rect_.h = surf.get_height();
        }
        catch (video_ctrl::exception &e)
        {
            log("ERROR: " + std::string(e.what()));
            return false;
        }

        return true;
    }

    /// Copy from a surface
    ///     @param surface - preloaded surface
    ///     @return true on success
    bool texture::create_from_surface(const surface &surface) noexcept
    {
        if (!rend_.set_current_context())
        {
            return false;
        }

        gl_call(glGenTextures(1, &texture_));

        if (surface.surface_type_ == surface::surface_type::raw)
        {
            rend_.set_texture(texture_, 0, wrap_type::wrap_clamp, interpolation_type::interpolate_linear);

            GLenum format = static_cast<GLenum> (get_opengl_pixel_format(surface.get_type()));
            int32_t internal_format = GL_RGBA;
            pixel_type_ = pix_type::rgba;

            switch(surface.get_type())
            {
                case pix_type::gray:
                    internal_format = format;
                    pixel_type_ = surface.get_type();
                break;
                default:

                break;
            }
            gl_call(glTexImage2D(GL_TEXTURE_2D, 0, internal_format, surface.get_width(), surface.get_height(), 0, format,
                         GL_UNSIGNED_BYTE, surface.get_pixels()));

            rend_.reset_texture(0);
        }
        else if (surface.surface_type_ == surface::surface_type::compress)
        {
#ifdef HAS_GLI_LIB
            auto& compress_surface = *surface.compress_surface_;

            gli::gl gl(gli::gl::PROFILE_GL33);
            auto format = gl.translate(compress_surface.format(), compress_surface.swizzles());
            GLenum target = gl.translate(compress_surface.target());

            glBindTexture(target, texture_);
            glTexParameteri(target, GL_TEXTURE_BASE_LEVEL, 0);
            glTexParameteri(target, GL_TEXTURE_MAX_LEVEL, static_cast<GLint>(compress_surface.levels() - 1));
            glTexParameteri(target, GL_TEXTURE_SWIZZLE_R, format.Swizzles[0]);
            glTexParameteri(target, GL_TEXTURE_SWIZZLE_G, format.Swizzles[1]);
            glTexParameteri(target, GL_TEXTURE_SWIZZLE_B, format.Swizzles[2]);
            glTexParameteri(target, GL_TEXTURE_SWIZZLE_A, format.Swizzles[3]);

            {
                auto extent = compress_surface.extent();
                auto face_total = static_cast<GLsizei>(compress_surface.layers() * compress_surface.faces());

                switch(compress_surface.target())
                {
                case gli::TARGET_1D:
                    glTexStorage1D(target, static_cast<GLint>(compress_surface.levels()), format.Internal, extent.x);
                    break;
                case gli::TARGET_1D_ARRAY:
                case gli::TARGET_2D:
                case gli::TARGET_CUBE:
                    glTexStorage2D(target, static_cast<GLint>(compress_surface.levels()), format.Internal,
                                   extent.x, compress_surface.target() == gli::TARGET_2D ? extent.y : face_total);
                    break;
                case gli::TARGET_2D_ARRAY:
                case gli::TARGET_3D:
                case gli::TARGET_CUBE_ARRAY:
                    glTexStorage3D(target, static_cast<GLint>(compress_surface.levels()), format.Internal,
                                   extent.x, extent.y, compress_surface.target() == gli::TARGET_3D ? extent.z : face_total);
                    break;
                default:
                    glBindTexture(target, 0);
                    glDeleteTextures(1, &texture_);
                    return false;
                }
            }

            for(std::size_t layer = 0; layer < compress_surface.layers(); ++layer)
            {
                for(std::size_t face = 0; face < compress_surface.faces(); ++face)
                {
                    for(std::size_t level = 0; level < compress_surface.levels(); ++level)
                    {
                        auto layer_gl = static_cast<GLsizei>(layer);
                        glm::tvec3<GLsizei> extent(compress_surface.extent(level));
                        if (gli::is_target_cube(compress_surface.target()))
                        {
                            target = static_cast<GLenum>(GL_TEXTURE_CUBE_MAP_POSITIVE_X + face);
                        }

                        switch(compress_surface.target())
                        {
                        case gli::TARGET_1D:
                            if(gli::is_compressed(compress_surface.format()))
                            {
                                glCompressedTexSubImage1D(target, static_cast<GLint>(level), 0, extent.x,
                                                          format.Internal, static_cast<GLsizei>(compress_surface.size(level)),
                                                          compress_surface.data(layer, face, level));
                            }
                            else
                            {
                                glTexSubImage1D(target, static_cast<GLint>(level), 0, extent.x,
                                                format.External, format.Type,
                                                compress_surface.data(layer, face, level));
                            }
                            break;
                        case gli::TARGET_1D_ARRAY:
                        case gli::TARGET_2D:
                        case gli::TARGET_CUBE:
                            if(gli::is_compressed(compress_surface.format()))
                            {
                                glCompressedTexSubImage2D(target, static_cast<GLint>(level), 0, 0, extent.x,
                                                          compress_surface.target() == gli::TARGET_1D_ARRAY ? layer_gl : extent.y,
                                                          format.Internal, static_cast<GLsizei>(compress_surface.size(level)),
                                                          compress_surface.data(layer, face, level));
                            }
                            else
                            {
                                glTexSubImage2D(target, static_cast<GLint>(level), 0, 0, extent.x,
                                                compress_surface.target() == gli::TARGET_1D_ARRAY ? layer_gl : extent.y,
                                                format.External, format.Type,
                                                compress_surface.data(layer, face, level));
                            }
                            break;
                        case gli::TARGET_2D_ARRAY:
                        case gli::TARGET_3D:
                        case gli::TARGET_CUBE_ARRAY:
                            if(gli::is_compressed(compress_surface.format()))
                            {
                                glCompressedTexSubImage3D(target, static_cast<GLint>(level), 0, 0, 0,
                                                          extent.x, extent.y,
                                                          compress_surface.target() == gli::TARGET_3D ? extent.z : layer_gl,
                                                          format.Internal, static_cast<GLsizei>(compress_surface.size(level)),
                                                          compress_surface.data(layer, face, level));
                            }
                            else
                            {
                                glTexSubImage3D(target, static_cast<GLint>(level), 0, 0, 0,
                                                extent.x, extent.y,
                                                compress_surface.target() == gli::TARGET_3D ? extent.z : layer_gl,
                                                format.External, format.Type,
                                                compress_surface.data(layer, face, level));
                            }
                            break;
                        default:
                            glBindTexture(target, 0);
                            glDeleteTextures(1, &texture_);
                            return false;
                        }
                    }
                }
            }

            glBindTexture(target, 0);
#endif
        }
        else
        {
            return false;
        }

        return true;
    }

    /// Main drawing function
    ///     @param src_rect - image cropper
    ///     @param dest_rect - destination polygon
    ///     @param blit - true to blend
    ///     @param flip - optional texture coordinates flipping
    ///     @param set_curr_context - soon to be pointless (moving all functionality to renderer, where these checks occur all the time)
    ///     @return true on success
    bool texture::draw(const rect& src_rect, const rect& dest_rect, const bool blit,
                       const flip_format flip, const bool set_curr_context) const noexcept
    {
        // Check texture and context state
        if (texture_ == 0 || (set_curr_context && !rend_.set_current_context()))
        {
            return false;
        }
        
        // Calculate texture coordinates
        tcoords tc = rect_.get_cropped_texture_coord(src_rect);
        switch (flip)
        {
            case flip_format::horizontal:
                std::swap(tc.x, tc.y);
                break;
            case flip_format::vertical:
                std::swap(tc.w, tc.h);
                break;
            case flip_format::both:
                std::swap(tc.x, tc.y);
                std::swap(tc.w, tc.h);
                break;
            default: break;
        }

        int dest_right = dest_rect.x + dest_rect.w;
        int dest_bottom = dest_rect.y + dest_rect.h;
        auto xdisplay = rend_.win_.get_xdisplay();
        
        rend_.set_texture(texture_, 0, wrap_type::wrap_repeat, interpolation_type::interpolate_linear);
        
        if (format_type_ == format_type::pixmap)
        {
            _glXBindTexImageEXT(xdisplay, glx_pixmap_, GLX_FRONT_LEFT_EXT, nullptr);
            XSync(xdisplay, False);
        }

        if (blit)
        {
            rend_.set_blending_mode(blending_mode::blend_normal);
        }

        glBegin(GL_QUADS);
            glTexCoord2f(tc.x, tc.w); glVertex2i(dest_rect.x, dest_rect.y);
            glTexCoord2f(tc.y, tc.w); glVertex2i(dest_right, dest_rect.y);
            glTexCoord2f(tc.y, tc.h); glVertex2i(dest_right, dest_bottom);
            glTexCoord2f(tc.x, tc.h); glVertex2i(dest_rect.x, dest_bottom);
        glEnd();

//        if (blit)
//        {
//            rend_.set_blending_mode(blending_mode::blend_none);
//        }

        if (format_type_ == format_type::pixmap)
        {
            _glXReleaseTexImageEXT(xdisplay, glx_pixmap_, GLX_FRONT_LEFT_EXT);
            XSync(xdisplay, False);
        }
        
        rend_.reset_texture(0);
        return check_for_error("copy");
    }

    /// Apply a rotation around a point before drawing the texture
    ///     @param src_rect - crop the image with this rect
    ///     @param dest_rect - the polygon at which to apply the texture
    ///     @param angle - angle of rotation (around texture's top-left corner)
    ///     @param flip - flip the texture coordinates
    ///     @param blit - whether or not to blend
    ///     @return true on success
    bool texture::draw_rotated(const rect &src_rect, const rect &dest_rect, const float angle,
                               const flip_format flip, bool blit) const noexcept
    {
        if (!src_rect.is_inner_of(rect_))
        {
            return false;
        }

        // Backup the transformation
        glPushMatrix();
        // Translate to pivot of rotation
        glTranslatef(dest_rect.x, dest_rect.y, 0);  
        // Rotate around new pivot
        glRotatef(angle, 0, 0, 1);

        rect rotate_dest_rect(-dest_rect.w/2, -dest_rect.h/2, dest_rect.w, dest_rect.h);
        if (!draw(src_rect, rotate_dest_rect, blit, flip, false))
        {
            return false;
        }

        glPopMatrix(); // return old matrix before translate and rotation

        return check_for_error("draw_rotated");
    }

    /// Apply a scale before drawing the texture
    ///     @param src_rect - crop the image with this rect
    ///     @param dest_rect - the polygon at which to apply the texture
    ///     @param angle - angle of rotation (around texture's top-left corner)
    ///     @param flip - flip the texture coordinates
    ///     @param blit - whether or not to blend
    ///     @return true on success
    bool texture::draw_scaled(const rect &src_rect, const rect &dest_rect, const float scale_x, const float scale_y,
                              const flip_format flip, bool blit) const noexcept
    {
        if (scale_x <= 0.0f || scale_y <= 0.0f || !src_rect.is_inner_of(rect_))
        {
            return false;
        }

        // Backup the transformation
        glPushMatrix();
        // Translate to pivot of rotation
        glTranslatef(dest_rect.x, dest_rect.y, 0);
        // Rescale the texture
        glScalef(scale_x, scale_y, 1.0);

        rect rotate_dest_rect(-dest_rect.w/2, -dest_rect.h/2, dest_rect.w, dest_rect.h);
        if (!draw(src_rect, rotate_dest_rect, blit, flip, false))
        {
            return false;
        }
        
        // Restore transformation before rescale
        glPopMatrix(); 

        return check_for_error("draw_scaled");
    }

    /// Check current ogl state for error
    ///     @param function_name
    ///     @return true if no error occurs
    bool texture::check_for_error(const std::string& function_name) const noexcept
    {
#ifdef EGT_DEVELOP
        const GLenum result = glGetError();
        if (result != GL_NO_ERROR)
        {
            log("ERROR: Problem with Texture::" + function_name + "() " + std::to_string(result));
            return false;
        }
#endif

        return true;
    }

    /// Hat pixel format to opengl pixel format converter
    ///     @param pixel_type - hat format to convert
    ///     @return the opengl format
    int32_t texture::get_opengl_pixel_format(const pix_type &pixel_type) const
    {
        int32_t pixel_format = GL_RGBA;
        switch (pixel_type)
        {
            case pix_type::gray:
                pixel_format = GL_RED;
                break;
            case pix_type::rgb:
                pixel_format = GL_RGB;
                break;
            case pix_type::rgba:
                pixel_format = GL_RGBA;
                break;
        }

        return pixel_format;
    }

    /// Upload new data to VRAM buffer (from surface)
    ///     @param point - offset inside texture pixelspace
    ///     @param surface - surface to copy from
    ///     @return true on success
    bool texture::update(const point &point, const surface &surface)
    {
        rect rect { point.x, point.y, surface.get_width(), surface.get_height() };
        return update(rect, surface.get_type(), surface.get_pixels());
    }

    /// Upload new data to VRAM buffer (from raw data)
    ///     @param rect - rectangle to copy
    ///     @param pix_format - hat pixel format
    ///     @param buffer - data to copy from
    ///     @return true on success
    bool texture::update(const rect &rect, pix_type pix_format, const uint8_t *buffer)
    {
        if (format_type_ != format_type::target)
        {
            return false;
        }

        const auto format = static_cast<GLenum> (get_opengl_pixel_format(pix_format));
        rend_.set_texture(texture_, 0, wrap_type::wrap_repeat, interpolation_type::interpolate_linear);
        gl_call(glTexSubImage2D(GL_TEXTURE_2D, 0, rect.x, rect.y, rect.w, rect.h, format, GL_UNSIGNED_BYTE, buffer));
        rend_.reset_texture(0);
        return check_for_error("update_texture");
    }

    /// Read pixels from the texture (from VRAM - slow!)
    ///     @param rect - rectangle to read
    ///     @param type - hat pixel format
    ///     @param buffer - [out] data goes here
    ///     @return true on success
    bool texture::read_pixels(const rect &rect, pix_type type, char *buffer)
    {
        if (!rend_.set_current_context())
        {
            return false;
        }

        gl_call(glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fbo_));
        gl_call(glReadPixels(rect.x, rect.y, rect.w, rect.h, type == pix_type::rgba ? GL_BGRA : GL_BGR, GL_UNSIGNED_BYTE, buffer));
        rend_.set_old_framebuffer();
        return check_for_error("read_pixels");
    }

    /// Draw wrapped around a transformation matrix
    ///     @param src_rect - cropper
    ///     @param dest_rect - polygon to draw onto
    ///     @param transform - transformation matrix
    ///     @return true on success
    bool texture::draw(const rect &src_rect, const rect &dest_rect, const math::transformf& transform) const noexcept
    {
        rend_.push_transform(transform);
        const bool result = draw(src_rect, dest_rect, rend_.current_color_.a < 255, flip_format::none, true);
        rend_.pop_transform();
        return result;
    }
    
    bool texture::draw(const point &dest_point, const flip_format flip, const bool blit) const noexcept
    {
        const rect dest_rect(dest_point.x, dest_point.y, rect_.w, rect_.h);
        return draw(rect_, dest_rect, blit, flip);
    }

    bool texture::draw(const rect& dest_rect, const flip_format flip, const bool blit) const noexcept
    {
        return draw(rect_, dest_rect, blit, flip);
    }

    bool texture::draw_rotated(const point& dest_point, const float angle, const flip_format flip, const bool blit) const noexcept
    {
        const rect dest_rect(dest_point.x, dest_point.y, rect_.w, rect_.h);
        return draw_rotated(rect_, dest_rect, angle, flip, blit);
    }

    bool texture::draw_rotated(const rect& dest_rect, const float angle, const flip_format flip, const bool blit) const noexcept
    {
        return draw_rotated(rect_, dest_rect, angle, flip, blit);
    }

    bool texture::draw_scaled(const point& dest_point, const float scale, const flip_format flip, const bool blit) const noexcept
    {
        const rect dest_rect(dest_point.x, dest_point.y, rect_.w, rect_.h);
        return draw_scaled(rect_, dest_rect, scale, scale, flip, blit);
    }

    bool texture::draw_scaled(const rect& dest_rect, const float scale, const flip_format flip, const bool blit) const noexcept
    {
        return draw_scaled(rect_, dest_rect, scale, scale, flip, blit);
    }


    /// Generate mipmaps for the texture. Works only for target textures (don't know why)
    ///     @return true on success
    bool texture::generate_mipmap() noexcept
    {
        if (format_type_ != format_type::target || generated_mipmap_ || !rend_.set_current_context())
        {
            return false;
        }

        gl_call(glBindTexture(GL_TEXTURE_2D, texture_));
        gl_call(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST));
        gl_call(glGenerateMipmap(GL_TEXTURE_2D));
        gl_call(glBindTexture(GL_TEXTURE_2D, 0));

        generated_mipmap_ = check_for_error("generate_mipmap");
        return generated_mipmap_;
    }
}
