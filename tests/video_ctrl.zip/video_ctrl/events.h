#pragma once

#include <cstdint>
#include <string>

#include "point.h"

namespace video_ctrl
{
    namespace platform
    {
        enum class key
        {
            unknown = -1,  ///< Unhandled key
            A,             ///< The A key
            B,             ///< The B key
            C,             ///< The C key
            D,             ///< The D key
            E,             ///< The E key
            F,             ///< The F key
            G,             ///< The G key
            H,             ///< The H key
            I,             ///< The I key
            J,             ///< The J key
            K,             ///< The K key
            L,             ///< The L key
            M,             ///< The M key
            N,             ///< The N key
            O,             ///< The O key
            P,             ///< The P key
            Q,             ///< The Q key
            R,             ///< The R key
            S,             ///< The S key
            T,             ///< The T key
            U,             ///< The U key
            V,             ///< The V key
            W,             ///< The W key
            X,             ///< The X key
            Y,             ///< The Y key
            Z,             ///< The Z key
            Num0,          ///< The 0 key
            Num1,          ///< The 1 key
            Num2,          ///< The 2 key
            Num3,          ///< The 3 key
            Num4,          ///< The 4 key
            Num5,          ///< The 5 key
            Num6,          ///< The 6 key
            Num7,          ///< The 7 key
            Num8,          ///< The 8 key
            Num9,          ///< The 9 key
            Escape,        ///< The Escape key
            LBracket,      ///< The [ key
            RBracket,      ///< The ] key
            SemiColon,     ///< The ; key
            Comma,         ///< The , key
            Period,        ///< The . key
            Quote,         ///< The ' key
            Slash,         ///< The / key
            BackSlash,     ///< The \ key
            Tilde,         ///< The ~ key
            Equal,         ///< The = key
            Dash,          ///< The - key
            Space,         ///< The Space key
            Return,        ///< The Return key
            BackSpace,     ///< The Backspace key
            Tab,           ///< The Tabulation key
            PageUp,        ///< The Page up key
            PageDown,      ///< The Page down key
            Menu,          ///< The Menu key
            End,           ///< The End key
            Home,          ///< The Home key
            Insert,        ///< The Insert key
            Delete,        ///< The Delete key
            Add,           ///< The + key
            Subtract,      ///< The - key
            Multiply,      ///< The * key
            Divide,        ///< The / key

            Right,         ///< Right arrow
            Left,          ///< Left arrow
            Down,          ///< Down arrow
            Up,            ///< Up arrow

            Numpad0,        ///< The numpad 0 key
            Numpad1,        ///< The numpad 1 key
            Numpad2,        ///< The numpad 2 key
            Numpad3,        ///< The numpad 3 key
            Numpad4,        ///< The numpad 4 key
            Numpad5,        ///< The numpad 5 key
            Numpad6,        ///< The numpad 6 key
            Numpad7,        ///< The numpad 7 key
            Numpad8,        ///< The numpad 8 key
            Numpad9,        ///< The numpad 9 key
            NumpadPeriod,   ///< The numpad . key
            NumpadDivide,   ///< The numpad / key
            NumpadMultiply, ///< The numpad * key
            NumpadSubtract, ///< The numpad - key
            NumpadAdd,      ///< The numpad + key
            NumpadEnter,    ///< The numpad 'Enter' key

            F1,            ///< The F1 key
            F2,            ///< The F2 key
            F3,            ///< The F3 key
            F4,            ///< The F4 key
            F5,            ///< The F5 key
            F6,            ///< The F6 key
            F7,            ///< The F7 key
            F8,            ///< The F8 key
            F9,            ///< The F9 key
            F10,           ///< The F10 key
            F11,           ///< The F11 key
            F12,           ///< The F12 key
            F13,           ///< The F13 key
            F14,           ///< The F14 key
            F15,           ///< The F15 key
            Pause          ///< The Pause key
        };

        enum class event_type
        {
            unknown,
            quit,
            window_pointer_focus,
            window_keyboard_focus,
            window_resized,
            window_closed,
            key,
            pointer,
            wheel,
            text,
        };

        enum class key_state
        {
            unknown,
            pressed,
            released
        };

        enum class pointer_state
        {
            unknown,
            pressed,
            released,
            move,
            nomove,
        };

        struct key_event
        {
            key key_ = platform::key::unknown;
            bool shift_pressed_ = false;
            bool ctrl_pressed_ = false;
            bool alt_pressed_ = false;
            bool super_pressed_ = false;
            key_state state_ = key_state::unknown;
            uint32_t window_id_ = 0;
        };

        struct pointer_event
        {
            static const uint8_t INVALID_ID = 255;

            uint8_t id_ = INVALID_ID;
            point point_;
            point raw_point_;
            pointer_state state_ = pointer_state::unknown;
            uint32_t window_id_ = 0;
            
        };

        struct wheel_event
        {
            point point_;
            uint32_t window_id_ = 0;
        };

        struct text_event
        {
            std::string text;
            uint32_t window_id_ = 0;
        };

        struct resize_event
        {
            int32_t width_ = 0;
            int32_t height_ = 0;
            uint32_t window_id_ = 0;
        };
        
        struct focus_event
        {
            bool focused_ = false;
            uint32_t window_id_ = 0;
        };
        struct close_event
        {
            uint32_t window_id_ = 0;
        };
        struct event
        {
            event_type type = event_type::unknown;

            key_event key;
            pointer_event pointer;
            wheel_event wheel;
            text_event text;
            resize_event resize;
            focus_event focus;
            close_event close;
        };
    }
}
