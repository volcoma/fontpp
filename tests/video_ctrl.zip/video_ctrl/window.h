#pragma once

#include <map>
#include <memory>
#include <X11/Xlib.h>

#include "rect.h"
#include "point.h"
#include "cursor.h"

struct SDL_Window; // SDL CLASS Definition

struct wl_display;
struct wl_surface;

namespace video_ctrl
{
    namespace platform
    {
        struct event;
    }

    class renderer;

    class window
    {
    public:
        struct options
        {
            bool vsync_ = true;
            bool resizable_ = false;
            bool screen_saver_ = true;
            bool opengl_ = true;

            constexpr options() noexcept {}
            constexpr options(bool vsync, bool resizable, bool screen_saver, bool opengl) noexcept
                : vsync_(vsync), resizable_(resizable), screen_saver_(screen_saver), opengl_(opengl) {}
            ~options() = default;
        };

        window(const rect &window_rect, const std::string &win_name = "Win", const options &opts = {});
        ~window() noexcept;

        window(const window &other) = delete;
        window(window &&other) = delete;

        renderer& get_renderer() const;

        Display* get_xdisplay() const noexcept;
        Drawable get_drawable() const noexcept;
        wl_display* get_wl_display() const noexcept;
        wl_surface* get_wl_surface() const noexcept;
        inline const video_ctrl::rect& get_rect() const noexcept { return rect_; }
        
        uint32_t get_id() const;
        point get_position() const;
        void set_position(const point& p);
        void request_focus() const;
        void request_close() const;
        bool has_focus() const;
        
        void set_size(uint32_t width, uint32_t height) const;
        void hide() const;
        void show() const;
        void hide_cursor() const;
        void set_cursor(cursor::type type);
        void show_cursor() const;
        void enable_screen_saver();
        void disable_screen_saver();
        void maximize() const;
        void minimize() const;
        void restore() const;
        bool set_opacity(float opacity) const;
    protected: 
        friend class renderer;
        void handle_event(const platform::event& e);
        
        struct win_deleter
        {
            void operator()(SDL_Window* &win);
        };

        std::unique_ptr<SDL_Window, win_deleter> create_win(const rect &window_rect, const std::string &win_name = "Win",
                                                            const options &opts = {});
        void resize(int new_width, int new_height) noexcept;
        void presnet() noexcept;

        void respect_compositor();

        std::unique_ptr<SDL_Window, win_deleter> sdl_win_;
        rect rect_ {};
        std::unique_ptr<renderer> render_;
        std::map<cursor::type, std::unique_ptr<cursor>> cursors_;
    };
}
