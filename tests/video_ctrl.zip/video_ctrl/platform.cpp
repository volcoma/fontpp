#include "platform.h"

#include "logger.h"

#include <SDL2/SDL.h>

#include <iostream>
#include <queue>

namespace video_ctrl
{
    exception::exception(const std::string &reason)
        : std::runtime_error(reason)
    {
    }

    bool platform::init()
    {
        auto init_values = SDL_INIT_VIDEO;

        if(SDL_Init(init_values) < 0)
        {
            log("ERROR: Cannot init SDL library.");
            return false;
        }

        if(!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
        {
            log("ERROR: Cannot set SDL_HINT_RENDER_SCALE_QUALITY to 1.");
            SDL_Quit();
            return false;
        }

        return true;
    }

    bool platform::destroy()
    {
        SDL_Quit();

        return true;
    }

    int platform::get_display_count()
    {
        return SDL_GetNumVideoDisplays();
    }

    rect platform::get_display_rect(int display_id)
    {
        rect result;
        SDL_GetDisplayBounds(display_id, reinterpret_cast<SDL_Rect*>(&result));

        return result;
    }

    std::string platform::get_clipboard_text()
    {
        return std::string(SDL_GetClipboardText());
    }

    void platform::set_clipboard_text(const std::string& text)
    {
        SDL_SetClipboardText(text.c_str());
    }

#ifdef EGT_DEVELOP
// events
namespace
{
uint8_t get_pointer_id(const SDL_Event& event)
{
    switch(event.button.button)
    {
        case SDL_BUTTON_LEFT:
            return 0;

        case SDL_BUTTON_RIGHT:
            return 1;

        case SDL_BUTTON_MIDDLE:
            return 2;

        default:
            return platform::pointer_event::INVALID_ID;
    }
}

platform::key convert_event(SDL_Scancode key_code)
{
    static const std::map<SDL_Scancode, platform::key> keys_connection_map = {
        {SDL_SCANCODE_A, platform::key::A},
        {SDL_SCANCODE_B, platform::key::B},
        {SDL_SCANCODE_C, platform::key::C},
        {SDL_SCANCODE_D, platform::key::D},
        {SDL_SCANCODE_E, platform::key::E},
        {SDL_SCANCODE_F, platform::key::F},
        {SDL_SCANCODE_G, platform::key::G},
        {SDL_SCANCODE_H, platform::key::H},
        {SDL_SCANCODE_I, platform::key::I},
        {SDL_SCANCODE_J, platform::key::J},
        {SDL_SCANCODE_K, platform::key::K},
        {SDL_SCANCODE_L, platform::key::L},
        {SDL_SCANCODE_M, platform::key::M},
        {SDL_SCANCODE_N, platform::key::N},
        {SDL_SCANCODE_O, platform::key::O},
        {SDL_SCANCODE_P, platform::key::P},
        {SDL_SCANCODE_Q, platform::key::Q},
        {SDL_SCANCODE_R, platform::key::R},
        {SDL_SCANCODE_S, platform::key::S},
        {SDL_SCANCODE_T, platform::key::T},
        {SDL_SCANCODE_U, platform::key::U},
        {SDL_SCANCODE_V, platform::key::V},
        {SDL_SCANCODE_W, platform::key::W},
        {SDL_SCANCODE_X, platform::key::X},
        {SDL_SCANCODE_Y, platform::key::Y},
        {SDL_SCANCODE_Z, platform::key::Z},

        {SDL_SCANCODE_0, platform::key::Num0},
        {SDL_SCANCODE_1, platform::key::Num1},
        {SDL_SCANCODE_2, platform::key::Num2},
        {SDL_SCANCODE_3, platform::key::Num3},
        {SDL_SCANCODE_4, platform::key::Num4},
        {SDL_SCANCODE_5, platform::key::Num5},
        {SDL_SCANCODE_6, platform::key::Num6},
        {SDL_SCANCODE_7, platform::key::Num7},
        {SDL_SCANCODE_8, platform::key::Num8},
        {SDL_SCANCODE_9, platform::key::Num9},

        {SDL_SCANCODE_ESCAPE, platform::key::Escape},
        {SDL_SCANCODE_LEFTBRACKET, platform::key::LBracket},
        {SDL_SCANCODE_RIGHTBRACKET, platform::key::RBracket},
        {SDL_SCANCODE_SEMICOLON, platform::key::SemiColon},
        {SDL_SCANCODE_COMMA, platform::key::Comma},
        {SDL_SCANCODE_PERIOD, platform::key::Period},
        {SDL_SCANCODE_APOSTROPHE, platform::key::Quote},
        {SDL_SCANCODE_SLASH, platform::key::Slash},
        {SDL_SCANCODE_BACKSLASH, platform::key::BackSlash},
        {SDL_SCANCODE_GRAVE, platform::key::Tilde},
        {SDL_SCANCODE_EQUALS, platform::key::Equal},
        {SDL_SCANCODE_MINUS, platform::key::Dash},
        {SDL_SCANCODE_SPACE, platform::key::Space},
        {SDL_SCANCODE_RETURN, platform::key::Return},
        {SDL_SCANCODE_BACKSPACE, platform::key::BackSpace},
        {SDL_SCANCODE_TAB, platform::key::Tab},
        {SDL_SCANCODE_PAGEUP, platform::key::PageUp},
        {SDL_SCANCODE_PAGEDOWN, platform::key::PageDown},
        {SDL_SCANCODE_MENU, platform::key::Menu},
        {SDL_SCANCODE_END, platform::key::End},
        {SDL_SCANCODE_HOME, platform::key::Home},
        {SDL_SCANCODE_INSERT, platform::key::Insert},
        {SDL_SCANCODE_DELETE, platform::key::Delete},
        //{SDL_SCANCODE_PLUS, platform::key::Add},
        {SDL_SCANCODE_MINUS, platform::key::Subtract},
        //{SDL_SCANCODE_ASTERISK, platform::key::Multiply},
        //{SDL_SCANCODE_SLASH, platform::key::Divide},

        {SDL_SCANCODE_RIGHT, platform::key::Right},
        {SDL_SCANCODE_LEFT, platform::key::Left},
        {SDL_SCANCODE_DOWN, platform::key::Down},
        {SDL_SCANCODE_UP, platform::key::Up},

        {SDL_SCANCODE_KP_0, platform::key::Numpad0},
        {SDL_SCANCODE_KP_1, platform::key::Numpad1},
        {SDL_SCANCODE_KP_2, platform::key::Numpad2},
        {SDL_SCANCODE_KP_3, platform::key::Numpad3},
        {SDL_SCANCODE_KP_4, platform::key::Numpad4},
        {SDL_SCANCODE_KP_5, platform::key::Numpad5},
        {SDL_SCANCODE_KP_6, platform::key::Numpad6},
        {SDL_SCANCODE_KP_7, platform::key::Numpad7},
        {SDL_SCANCODE_KP_8, platform::key::Numpad8},
        {SDL_SCANCODE_KP_9, platform::key::Numpad9},
        {SDL_SCANCODE_KP_PERIOD, platform::key::NumpadPeriod},
        {SDL_SCANCODE_KP_DIVIDE, platform::key::NumpadDivide},
        {SDL_SCANCODE_KP_MULTIPLY, platform::key::NumpadMultiply},
        {SDL_SCANCODE_KP_MINUS, platform::key::NumpadSubtract},
        {SDL_SCANCODE_KP_PLUS, platform::key::NumpadAdd},
        {SDL_SCANCODE_KP_ENTER, platform::key::NumpadEnter},

        {SDL_SCANCODE_F1, platform::key::F1},
        {SDL_SCANCODE_F2, platform::key::F2},
        {SDL_SCANCODE_F3, platform::key::F3},
        {SDL_SCANCODE_F4, platform::key::F4},
        {SDL_SCANCODE_F5, platform::key::F5},
        {SDL_SCANCODE_F6, platform::key::F6},
        {SDL_SCANCODE_F7, platform::key::F7},
        {SDL_SCANCODE_F7, platform::key::F8},
        {SDL_SCANCODE_F9, platform::key::F9},
        {SDL_SCANCODE_F10, platform::key::F10},
        {SDL_SCANCODE_F11, platform::key::F11},
        {SDL_SCANCODE_F12, platform::key::F12},
        {SDL_SCANCODE_F13, platform::key::F13},
        {SDL_SCANCODE_F14, platform::key::F14},
        {SDL_SCANCODE_F15, platform::key::F15},
        {SDL_SCANCODE_PAUSE, platform::key::Pause},
    };

    const auto find_it = keys_connection_map.find(key_code);
    if(find_it != keys_connection_map.cend())
    {
        return find_it->second;
    }

    return platform::key::unknown;
}
}
#endif

std::queue<platform::event>& get_event_queue()
{
    static std::queue<platform::event> event_queue;
    return event_queue;
}

bool platform::poll_event(platform::event& e)
{
    auto& event_queue = get_event_queue();
    if(!event_queue.empty())
    {
        e = event_queue.front();
        event_queue.pop();
        return true;
    }
    SDL_Event sdl_event;
    while(SDL_PollEvent(&sdl_event) != 0)
    {
#ifdef EGT_DEVELOP
        switch(sdl_event.type)
        {
            case SDL_QUIT:
                e.type = event_type::quit;
                return true;

            case SDL_KEYDOWN:
                e.type = event_type::key;
                e.key.state_ = key_state::pressed;
                e.key.key_ = convert_event(sdl_event.key.keysym.scancode);
                e.key.shift_pressed_ = ((SDL_GetModState() & KMOD_SHIFT) != 0);
                e.key.ctrl_pressed_ = ((SDL_GetModState() & KMOD_CTRL) != 0);
                e.key.alt_pressed_ = ((SDL_GetModState() & KMOD_ALT) != 0);
                e.key.super_pressed_ = ((SDL_GetModState() & KMOD_GUI) != 0);
                e.key.window_id_ = sdl_event.key.windowID;
                return true;

            case SDL_KEYUP:
                e.type = event_type::key;
                e.key.state_ = key_state::released;
                e.key.key_ = convert_event(sdl_event.key.keysym.scancode);
                e.key.shift_pressed_ = ((SDL_GetModState() & KMOD_SHIFT) != 0);
                e.key.ctrl_pressed_ = ((SDL_GetModState() & KMOD_CTRL) != 0);
                e.key.alt_pressed_ = ((SDL_GetModState() & KMOD_ALT) != 0);
                e.key.super_pressed_ = ((SDL_GetModState() & KMOD_GUI) != 0);
                e.key.window_id_ = sdl_event.key.windowID;
                return true;

            case SDL_TEXTINPUT:
                e.type = event_type::text;
                e.text.text = sdl_event.text.text;
                e.text.window_id_ = sdl_event.text.windowID;
                return true;

            case SDL_MOUSEMOTION:
                e.type = event_type::pointer;
                e.pointer.state_ = pointer_state::move;
                e.pointer.point_.x = sdl_event.motion.x;
                e.pointer.point_.y = sdl_event.motion.y;
                e.pointer.raw_point_ = e.pointer.point_;
                e.pointer.window_id_ = sdl_event.motion.windowID;
                return true;

            case SDL_MOUSEWHEEL:
                e.type = event_type::wheel;
                e.wheel.point_.x = sdl_event.wheel.x;
                e.wheel.point_.y = sdl_event.wheel.y;
                e.wheel.window_id_ = sdl_event.wheel.windowID;
                return true;

            case SDL_MOUSEBUTTONDOWN:
                e.type = event_type::pointer;
                e.pointer.state_ = pointer_state::pressed;
                e.pointer.id_ = get_pointer_id(sdl_event);
                e.pointer.point_.x = sdl_event.button.x;
                e.pointer.point_.y = sdl_event.button.y;
                e.pointer.raw_point_ = e.pointer.point_;
                e.pointer.window_id_ = sdl_event.button.windowID;
                return true;

            case SDL_MOUSEBUTTONUP:
                e.type = event_type::pointer;
                e.pointer.state_ = pointer_state::released;
                e.pointer.id_ = get_pointer_id(sdl_event);
                e.pointer.point_.x = sdl_event.button.x;
                e.pointer.point_.y = sdl_event.button.y;
                e.pointer.raw_point_ = e.pointer.point_;
                e.pointer.window_id_ = sdl_event.button.windowID;
                return true;

            case SDL_WINDOWEVENT:
                switch(sdl_event.window.event)
                {
                    case SDL_WINDOWEVENT_ENTER:
                        e.type = event_type::window_pointer_focus;
                        e.focus.focused_ = true;
                        e.focus.window_id_ = sdl_event.window.windowID;
                        return true;
                    case SDL_WINDOWEVENT_LEAVE:
                        e.type = event_type::window_pointer_focus;
                        e.focus.focused_ = false;
                        e.focus.window_id_ = sdl_event.window.windowID;
                        return true;
                    case SDL_WINDOWEVENT_FOCUS_GAINED:
                        e.type = event_type::window_keyboard_focus;
                        e.focus.focused_ = true;
                        e.focus.window_id_ = sdl_event.window.windowID;
                        return true;
                    case SDL_WINDOWEVENT_FOCUS_LOST:
                        e.type = event_type::window_keyboard_focus;
                        e.focus.focused_ = false;
                        e.focus.window_id_ = sdl_event.window.windowID;
                        return true;
                    case SDL_WINDOWEVENT_SIZE_CHANGED:
                        e.type = event_type::window_resized;
                        e.resize.width_ = sdl_event.window.data1;
                        e.resize.height_ = sdl_event.window.data2;
                        e.resize.window_id_ = sdl_event.window.windowID;
                        return true;
                    case SDL_WINDOWEVENT_CLOSE:
                        e.type = event_type::window_closed;
                        e.close.window_id_ = sdl_event.window.windowID;
                        return true;
                    default:
                        break;
                }

                break;
            default:
                break;
        }  
#endif
    }
    return false;
}

void platform::push_event(const platform::event& e)
{
    get_event_queue().push(e);
}

hpp::event<void(const platform::event&)>& platform::event_handler()
{
    static hpp::event<void(const platform::event&)> event_handler;

    return event_handler;
}

point platform::mouse::get_position()
{
    point p;
#ifdef EGT_DEVELOP
    SDL_GetGlobalMouseState(&p.x, &p.y);
#endif
    return p;
}

point platform::mouse::get_position(const window& wnd)
{
    point relative_point;
#ifdef EGT_DEVELOP
    point global_point = get_position();

    auto window_pos = wnd.get_position();
    relative_point.x = global_point.x - window_pos.x;
    relative_point.y = global_point.y - window_pos.y;
#endif
    return relative_point;
}

bool platform::mouse::is_button_pressed(platform::mouse::button b)
{
#ifdef EGT_DEVELOP
    SDL_PumpEvents();
    auto mouse_state = SDL_GetMouseState(NULL, NULL);
    switch(b)
    {
        case platform::mouse::button::left:
            return mouse_state & SDL_BUTTON(SDL_BUTTON_LEFT);
        case platform::mouse::button::right:
            return mouse_state & SDL_BUTTON(SDL_BUTTON_RIGHT);
        case platform::mouse::button::middle:
            return mouse_state & SDL_BUTTON(SDL_BUTTON_MIDDLE);
    }
#endif
    return false;
}

}
