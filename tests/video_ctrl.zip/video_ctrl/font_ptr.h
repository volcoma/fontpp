#pragma once

#include <memory>

namespace video_ctrl
{

struct font;
using font_ptr = std::shared_ptr<font>;

}
