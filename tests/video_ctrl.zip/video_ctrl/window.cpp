#include "window.h"

#include "renderer.h"
#include "platform.h"

#include <SDL2/SDL.h>
#include <SDL2/SDL_syswm.h>

namespace video_ctrl
{
    void window::win_deleter::operator()(SDL_Window* &win)
    {
        if (nullptr != win)
        {
            SDL_DestroyWindow(win);
            win = nullptr;
        }
    }

    std::unique_ptr<SDL_Window, window::win_deleter> window::create_win(const rect &window_rect,
                                                                        const std::string &win_name,
                                                                        const window::options &opts)
    {
        if (SDL_WasInit(SDL_INIT_VIDEO) == 0)
        {
            throw video_ctrl::exception("Platform is not inited.");
        }

        SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 0);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

        uint32_t sdl_win_opts = 0;
        if (opts.opengl_)
        {
            sdl_win_opts |= SDL_WINDOW_OPENGL;
        }
        if (opts.resizable_)
        {
            sdl_win_opts |= SDL_WINDOW_RESIZABLE;
            platform::event_handler().connect(this, &window::handle_event);
        }

        std::unique_ptr<SDL_Window, win_deleter> win;
        win.reset(SDL_CreateWindow(win_name.c_str(), window_rect.x, window_rect.y, window_rect.w,
                                   window_rect.h, sdl_win_opts));
 
        respect_compositor();
    
        if (!win)
        {
            throw video_ctrl::exception("Cannot create window.");
        }

        return win;
    }

    void window::resize(int new_width, int new_height) noexcept
    {
        render_->resize(new_width, new_height);
        rect_.w = new_width;
        rect_.h = new_height;
    }

    void window::presnet() noexcept
    {
        SDL_GL_SwapWindow(sdl_win_.get());
    }
    
    void window::respect_compositor()
    {
#ifdef EGT_DEVELOP        
        int compositor = 2;
        Atom bypass_compositor = XInternAtom(get_xdisplay(), "_NET_WM_BYPASS_COMPOSITOR", False);
        XChangeProperty(get_xdisplay(), get_drawable(), bypass_compositor, XA_CARDINAL, 32,
                        PropModeReplace, reinterpret_cast<uint8_t*>(&compositor), 1);

        XFlush(get_xdisplay());

        hide();
        show();
#endif
    }


    window::window(const rect &window_rect, const std::string &win_name, const window::options &opts)
        : sdl_win_(create_win(window_rect, win_name, opts)),
          rect_(0, 0, window_rect.w, window_rect.h),
          render_(opts.opengl_ ? new renderer(*this, opts.vsync_) : nullptr)
    {
        if (opts.screen_saver_)
        {
            enable_screen_saver();
        }
        else
        {
            disable_screen_saver();
        }

        for(int i = static_cast<int>(cursor::type::arrow); i < static_cast<int>(cursor::type::count); ++i)
        {
            cursors_.emplace(static_cast<cursor::type>(i), new cursor(static_cast<cursor::type>(i)));
        }
    }

    window::~window() noexcept
    {
        platform::event_handler().disconnect(this, &window::handle_event);
    }

    renderer &window::get_renderer() const
    {
        if (render_)
        {
            return *render_;
        }

        throw video_ctrl::exception("renderer is not inited.");
    }

    Display* window::get_xdisplay() const noexcept
    {
        SDL_SysWMinfo info;
        SDL_VERSION(&info.version); // Initialize info structure with SDL version info

        if(!SDL_GetWindowWMInfo(sdl_win_.get(),&info))
            return NULL;

        return info.info.x11.display;
    }

    Drawable window::get_drawable() const noexcept
    {
        SDL_SysWMinfo info;
        SDL_VERSION(&info.version); // Initialize info structure with SDL version info

        if(!SDL_GetWindowWMInfo(sdl_win_.get(),&info))
            return 0;

        return info.info.x11.window;
    }

    wl_display *window::get_wl_display() const noexcept
    {
        SDL_SysWMinfo info;
        SDL_VERSION(&info.version); // Initialize info structure with SDL version info

        if(!SDL_GetWindowWMInfo(sdl_win_.get(),&info))
            return 0;

        return info.info.wl.display;
    }

    wl_surface *window::get_wl_surface() const noexcept
    {
        SDL_SysWMinfo info;
        SDL_VERSION(&info.version); // Initialize info structure with SDL version info

        if(!SDL_GetWindowWMInfo(sdl_win_.get(),&info))
            return 0;

        return info.info.wl.surface;
    }
    
    uint32_t window::get_id() const
    {
        return SDL_GetWindowID(sdl_win_.get());
    }
    
    point window::get_position() const
    {
        point p;
        if(sdl_win_.get())
        {
            SDL_GetWindowPosition(sdl_win_.get(), &p.x, &p.y);
        }
        return p;
    }
    
    void window::set_position(const point &p)
    {
        if(sdl_win_.get())
        {
            SDL_SetWindowPosition(sdl_win_.get(), p.x, p.y);
        }
    }
    
    void window::request_focus() const
    {
        SDL_SetWindowInputFocus(sdl_win_.get());
    }
    
    void window::request_close() const
    {
        platform::event e;
        e.type = platform::event_type::window_closed;
        e.close.window_id_ = get_id();
        platform::push_event(e);
    }

    void window::hide_cursor() const
    {
        SDL_ShowCursor(SDL_DISABLE);
    }

    void window::set_cursor(cursor::type type)
    {
        auto& cursor = cursors_[type];
        if(cursor)
        {
            cursor->set();
        }
    }

    void window::show_cursor() const
    {
        SDL_ShowCursor(SDL_ENABLE);
    }

    void window::enable_screen_saver()
    {
        if (!SDL_IsScreenSaverEnabled())
        {
            SDL_EnableScreenSaver();
        }
    }

    void window::disable_screen_saver()
    {
        if (SDL_IsScreenSaverEnabled())
        {
            SDL_DisableScreenSaver();
        }
    }
    
    bool window::set_opacity(float opacity) const
    {
        return SDL_SetWindowOpacity(sdl_win_.get(), opacity) == 0;
    }

    void window::maximize() const
    {
        SDL_MaximizeWindow(sdl_win_.get());
    }
    
    void window::minimize() const
    {
        SDL_MinimizeWindow(sdl_win_.get());
    }
    
    void window::restore() const
    {
        SDL_RestoreWindow(sdl_win_.get());
    }

    void window::handle_event(const platform::event &e)
    {
        if(e.type == platform::event_type::window_resized)
        {
            //Check if this event for our window
            if(get_id() == e.resize.window_id_)
            {
                resize(e.resize.width_, e.resize.height_);
            }
        }
    }
    
    bool video_ctrl::window::has_focus() const
    {
        auto flags = SDL_GetWindowFlags(sdl_win_.get());
        return (flags & SDL_WINDOW_INPUT_FOCUS) != 0;
    }
    
    void window::set_size(uint32_t width, uint32_t height) const
    {
        SDL_SetWindowSize(sdl_win_.get(), static_cast<int>(width), static_cast<int>(height));
    }
    
    void window::hide() const
    {
        SDL_HideWindow(sdl_win_.get());
    }
    
    void window::show() const
    {
        SDL_ShowWindow(sdl_win_.get());
    }
    
}
