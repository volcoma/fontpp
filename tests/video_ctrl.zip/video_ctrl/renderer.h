#pragma once

#include <string>
#include <stack>

#include "color.h"
#include "draw_list.h"
#include "rect.h"
#include "shader.h"
#include "surface.h"
#include "texture.h"
#include "font_ptr.h"

namespace video_ctrl
{

class window;
struct font_info;

class renderer
{
public:
    // Create texture for unique use with these functions
    texture_ptr create_texture(const surface& surface) const noexcept;
    texture_ptr create_texture(const std::string& file_name) const noexcept;
    texture_ptr create_texture(int w, int h, pix_type pixel_type, texture::format_type format_tp) const noexcept;

    // Create shader for unique use with these functions
    shader_ptr create_shader(const char* fragment_code , const char* vertex_code) const noexcept;

    // comsumes font_info
    font_ptr create_font(font_info&& info) const noexcept;

    // Set colors & blending
    bool set_color(const color& color) noexcept;
    bool set_blending_mode(const blending_mode mode) const noexcept;
    
    // Bind textures
    bool set_texture(const uint32_t texture, uint32_t id = 0, 
                    texture::wrap_type wrap_type = texture::wrap_type::wrap_repeat, 
                    texture::interpolation_type interp_type = texture::interpolation_type::interpolate_linear) const noexcept;
    bool set_texture(texture_view texture, uint32_t id = 0,
                     texture::wrap_type wrap_type = texture::wrap_type::wrap_repeat, 
                     texture::interpolation_type interp_type = texture::interpolation_type::interpolate_linear) const noexcept;
    bool set_texture(const texture_ptr& texture, uint32_t id = 0, 
                     texture::wrap_type wrap_type = texture::wrap_type::wrap_repeat, 
                     texture::interpolation_type interp_type = texture::interpolation_type::interpolate_linear) const noexcept;
    void reset_texture(uint32_t id = 0) const noexcept;
    
    texture_ptr blur(const texture_ptr& texture, uint32_t passes = 2);

    // Transformation
    bool push_transform(const math::transformf& transform) const noexcept;
    bool pop_transform() const noexcept;
    bool reset_transform() const noexcept;

    // Draw primitives
    bool draw_array(const primitive_type prim, const uint32_t stride, const uint32_t vcount, const math::vec2* pos, const math::vec2* uvs = nullptr, const color* col = nullptr) const noexcept;
    bool draw_line(const point& start, const point& end, int line_width = 1) noexcept;
    bool draw_point(const point& point, int point_width = 1) noexcept;
    bool draw_rect(const rect& rect, bool filled = true, int line_width = 1) noexcept;
    bool draw_rect(const rect& rect, const math::transformf& transform, bool filled = true,
                   int line_width = 1) noexcept;
    bool draw_triangle(const point& p1, const point& p2, const point& p3, bool filled,
                       int line_width) noexcept;
    // Clipping
    bool set_clip_rect(const rect& rect) const noexcept;
    bool remove_clip_rect() const noexcept;
    bool set_clip_rect_only(const rect& rect) const noexcept;
    bool set_clip_planes(const rect& rect, const math::transformf& transform) const noexcept;
    bool remove_clip_planes() const noexcept;

    void set_line_width(float width) const noexcept;
    // Destinations
    bool push_fbo(const texture_ptr& texture);
    bool pop_fbo();
    bool reset_fbo();

    void present() noexcept;
    void clear(const color& color = {}) const noexcept;

    bool draw_cmd_list(const draw_list& list) const noexcept;

    // VSync
    bool enable_vsync() noexcept;
    bool disable_vsync() noexcept;

    const rect& get_rect() const;

    ~renderer();
    renderer(const renderer& other) = delete;
    renderer(renderer&& other) = delete;

private:
    friend class window;
    friend class texture;
    friend class shader;

    static constexpr int FARTHEST_Z = -1;

    struct context_deleter
    {
        void operator()(void*& context);
    };

    window& win_;
    std::unique_ptr<void, context_deleter> context_;
    rect rect_;

    mutable math::mat4x4 current_ortho_;
    std::stack<texture_ptr> fbo_stack_;

    color current_color_{color::white};
    bool vsync_enabled_ {false};
    vertex_buffer master_vbo;
    index_buffer master_ibo;
    font_ptr default_font_;

    renderer(window& win, bool vsync);

    void set_model_view(const uint32_t model, const rect& rect) const noexcept;
    void clear_fbo(uint32_t fbo_id, const color& color) const noexcept;
    bool set_current_context() const noexcept;
    void set_old_framebuffer() const noexcept;
    void resize(int new_width, int new_height) noexcept;
};
}
