#pragma once

namespace video_ctrl
{
    enum flip_format
    {
        none,
        horizontal,
        vertical,
        both
    };
}
