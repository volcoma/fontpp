#pragma once

namespace video_ctrl
{
    enum class pix_type
    {
        gray = 1,
        rgb = 3,
        rgba = 4
    };
}
