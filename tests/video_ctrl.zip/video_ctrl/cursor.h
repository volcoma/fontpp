#pragma once

#include <memory>

struct SDL_Cursor;

namespace video_ctrl
{
    class cursor
    {
    public:
        enum class type
        {
            arrow,      /**< Arrow */
            ibeam,      /**< I-beam */
            wait,       /**< Wait */
            crosshair,  /**< Crosshair */
            wait_arrow, /**< Small wait cursor (or Wait if not available) */
            size_nw_se, /**< Double arrow pointing northwest and southeast */
            size_ne_sw, /**< Double arrow pointing northeast and southwest */
            size_we,    /**< Double arrow pointing west and east */
            size_ns,    /**< Double arrow pointing north and south */
            size_all,   /**< Four pointed arrow pointing north, south, east, and west */
            no,         /**< Slashed circle or crossbones */
            hand,       /**< Hand */
            count
        };

        cursor(type t);
        ~cursor() noexcept = default;

        void set() const;
    private:
        struct cursor_deleter
        {
            void operator()(SDL_Cursor *&obj) noexcept;
        };

       // type type_;
        std::unique_ptr<SDL_Cursor, cursor_deleter> cursor_;
    };
}
