#include "proxy_renderer.h"

#include "renderer.h"
#include "platform.h"

namespace video_ctrl
{
    proxy_renderer::proxy_renderer(renderer &rend, int fbo_w, int fbo_h, bool force_fbo)
        : rend_(rend),
          fbo_(),
          force_fbo_{force_fbo}
    {
        resize_fbo(fbo_w, fbo_h);
    }

    texture_ptr proxy_renderer::create_texture(const surface &surface) const noexcept
    {
        return rend_.create_texture(surface);
    }

    texture_ptr proxy_renderer::create_texture(const std::string &file_name) const noexcept
    {
        return rend_.create_texture(file_name);
    }

    texture_ptr proxy_renderer::create_texture(int w, int h, pix_type pixel_type, texture::format_type format_tp) const noexcept
    {
        return rend_.create_texture(w, h, pixel_type, format_tp);
    }

    shader_ptr proxy_renderer::create_shader(const char *fragment_code, const char *vertex_code) const noexcept
    {
        return rend_.create_shader(fragment_code, vertex_code);
    }

    font_ptr proxy_renderer::create_font(font_info&& info) const noexcept
    {
        return rend_.create_font(std::move(info));
    }

    bool proxy_renderer::set_color(const color &color) noexcept
    {
        return rend_.set_color(color);
    }
    
    bool proxy_renderer::push_transform(const math::transformf& transform) noexcept
    {
        return rend_.push_transform(transform);        
    }
    
    bool proxy_renderer::pop_transform() noexcept
    {
        return rend_.pop_transform();
    }

    bool proxy_renderer::draw_line(const point &start, const point &end, int line_width) noexcept
    {
        return rend_.draw_line(start, end, line_width);
    }

    bool proxy_renderer::draw_point(const point &point, int point_width) noexcept
    {
        return rend_.draw_point(point, point_width);
    }

    bool proxy_renderer::draw_rect(const rect &rect, bool filled, int line_width) noexcept
    {
        return rend_.draw_rect(rect, filled, line_width);
    }

    bool proxy_renderer::set_clip_rect(const rect &rect) noexcept
    {
        return rend_.set_clip_rect(rect);
    }

    bool proxy_renderer::remove_clip_rect() noexcept
    {
        return rend_.remove_clip_rect();
    }

    bool proxy_renderer::set_clip_rect_only(const rect &rect) const noexcept
    {
        return rend_.set_clip_rect_only(rect);
    }
    
    bool proxy_renderer::set_clip_planes(const rect &rect, const math::transformf &transform) const noexcept
    {
        return rend_.set_clip_planes(rect, transform);
    }
    
    bool proxy_renderer::remove_clip_planes() const noexcept
    {
        return rend_.remove_clip_planes();
    }

    bool proxy_renderer::push_fbo(const texture_ptr& texture)
    {
        return rend_.push_fbo(texture);
    }

    bool proxy_renderer::pop_fbo()
    {
        return rend_.pop_fbo();
    }

    bool proxy_renderer::reset_fbo()
    {
        if (!rend_.reset_fbo())
        {
            return false;
        }

        if (fbo_)
        {
            return rend_.push_fbo(fbo_);
        }

        return true;
    }

    void proxy_renderer::begin_draw() noexcept
    {
        if (fbo_)
        {
            rend_.push_fbo(fbo_);
        }
    }

    void proxy_renderer::present_only() noexcept
    {
        rend_.present();
    }

    void proxy_renderer::copy_to_renderer_and_present()
    {
        if (fbo_)
        {
            set_color(color::white);
            copy_to_renderer();
        }
        present_only();
    }

    void proxy_renderer::copy_to_renderer(const rect &dest_rect)
    {
        if (!fbo_)
        {
            throw video_ctrl::exception("Cannot copy default renderer, because proxy renderer represent back buffer with this config.");
        }

        rend_.reset_fbo();
        auto fbo = fbo_;
        if (blur_fbo_)
        {
            fbo = rend_.blur(fbo_, 1);
        }

        if (dest_rect)
        {
            fbo->draw(dest_rect);
        }
        else
        {
            fbo->draw(rend_.get_rect());
        }
    }

    void proxy_renderer::copy_to_renderer(const rect &src_rect, const rect &dest_rect)
    {
        if (!fbo_)
        {
            throw video_ctrl::exception("Cannot copy default renderer, because proxy renderer represent back buffer with this config.");
        }

        if (!src_rect.is_inner_of(fbo_->get_rect()))
        {
            throw video_ctrl::exception("src_rect is not inner of fbo rect.");
        }

        rend_.reset_fbo();
        if (dest_rect)
        {
            fbo_->draw(src_rect, dest_rect, false);
        }
        else
        {
            fbo_->draw(src_rect, rend_.get_rect(), false);
        }
    }

    bool proxy_renderer::set_blending_mode(const blending_mode mode) const noexcept
    {
        return rend_.set_blending_mode(mode);
    }

    void proxy_renderer::copy_from(proxy_renderer &rend, const rect &dest_rect)
    {
        if (!fbo_)
        {
            throw video_ctrl::exception("Cannot copy from backbuffer yet.");
        }

        rend_.reset_fbo();
        if (dest_rect)
        {
            rend.fbo_->draw(dest_rect);
        }
        else
        {
            rend.fbo_->draw(fbo_->get_rect());
        }
    }

    void proxy_renderer::copy_from(proxy_renderer &rend, const rect &src_rect, const rect &dest_rect)
    {
        if (!fbo_)
        {
            throw video_ctrl::exception("Cannot copy from backbuffer yet.");
        }

        if (!src_rect.is_inner_of(fbo_->get_rect()))
        {
            throw video_ctrl::exception("src_rect is not inner of fbo rect.");
        }

        rend_.reset_fbo();
        if (dest_rect)
        {
            rend.fbo_->draw(src_rect, dest_rect, false);
        }
        else
        {
            rend.fbo_->draw(src_rect, fbo_->get_rect(), false);
        }
    }

    void proxy_renderer::clear(const color &color) noexcept
    {
        if (fbo_)
        {
            fbo_->clear(color);
        }
        else
        {
            rend_.clear(color);
        }
    }

    int proxy_renderer::get_width() const
    {
        if (fbo_)
        {
            return fbo_->get_rect().w;
        }

        return rend_.get_rect().w;
    }

    int proxy_renderer::get_height() const
    {
        if (fbo_)
        {
            return fbo_->get_rect().h;
        }

        return rend_.get_rect().h;
    }

    bool proxy_renderer::draw_cmd_list(const draw_list &list) const noexcept
    {
        return rend_.draw_cmd_list(list);
    }

    const rect &proxy_renderer::get_rect() const
    {
        if (fbo_)
        {
            return fbo_->get_rect();
        }

        return rend_.get_rect();
    }

    bool proxy_renderer::enable_vsync() noexcept
    {
        return rend_.enable_vsync();
    }

    bool proxy_renderer::disable_vsync() noexcept
    {
        return rend_.disable_vsync();
    }

    void proxy_renderer::resize_fbo(int fbo_w, int fbo_h)
    {
        rend_.reset_fbo();
        if (force_fbo_)
        {
            if (!fbo_)
            {
                fbo_ = rend_.create_texture(fbo_w, fbo_h, pix_type::rgba, texture::format_type::streaming);
                return;
            }

            auto& rend_rect = fbo_->get_rect();
            if (rend_rect.w != fbo_w || rend_rect.h != fbo_h)
            {
                fbo_ = rend_.create_texture(fbo_w, fbo_h, pix_type::rgba, texture::format_type::streaming);
            }
        }
        else
        {
            video_ctrl::rect fbo_rect {0, 0, fbo_w, fbo_h};
            if (rend_.get_rect() != fbo_rect)
            {
                if (!fbo_ || fbo_->get_rect() != fbo_rect)
                {
                    fbo_ = rend_.create_texture(fbo_w, fbo_h, pix_type::rgba, texture::format_type::streaming);
                }
            }
            else
            {
                fbo_ = {};
            }
        }


        {
            constexpr float enable_blur_scale_coef = 0.6f;

            const auto& rend_rect = rend_.get_rect();
            auto scale_w_coef = static_cast<float> (rend_rect.w) / fbo_w;
            auto scale_h_coef = static_cast<float> (rend_rect.h) / fbo_h;
            blur_fbo_ = scale_w_coef < enable_blur_scale_coef || scale_h_coef < enable_blur_scale_coef;
        }
    }
}
