#pragma once

#include <memory>

#include "color.h"
#include "rect.h"
#include "shader.h"
#include "surface.h"
#include "texture.h"
#include "draw_list.h"
#include "font_ptr.h"

namespace video_ctrl
{
    class renderer;
    class texture;
    struct font_info;

    class proxy_renderer
    {
    public:
        using ptr = std::shared_ptr<proxy_renderer>;
        using weak_ptr = std::weak_ptr<proxy_renderer>;
        ~proxy_renderer() = default;
        proxy_renderer(renderer &rend, int fbo_w, int fbo_h, bool force_fbo = false);
        proxy_renderer(proxy_renderer&) = delete;
        proxy_renderer(proxy_renderer&&) = delete;

        // create texture for unique use with these functions
        texture_ptr create_texture(const surface &surface) const noexcept;
        texture_ptr create_texture(const std::string &file_name) const noexcept;
        texture_ptr create_texture(int w, int h, pix_type pixel_type, texture::format_type format_tp) const noexcept;

        // create shader for unique use with this functions
        shader_ptr create_shader(const char *fragment_code = "", const char *vertex_code = "") const noexcept;

        font_ptr create_font(font_info&& info) const noexcept;

        bool set_color(const color &color) noexcept;
        bool push_transform(const math::transformf& transform) noexcept;
        bool pop_transform() noexcept;
        bool set_blending_mode(const blending_mode mode) const noexcept;

        bool draw_line(const point &start, const point &end, int line_width = 1) noexcept;
        bool draw_point(const point &point, int point_width = 1) noexcept;
        bool draw_rect(const rect &rect, bool filled = true, int line_width = 1) noexcept;
        bool set_clip_rect(const rect &rect) noexcept;
        bool remove_clip_rect() noexcept;

        bool set_clip_rect_only(const rect &rect) const noexcept;
        bool set_clip_planes(const rect &rect, const math::transformf &transform) const noexcept;
        bool remove_clip_planes() const noexcept;

        bool push_fbo(const texture_ptr& texture);
        bool pop_fbo();
        bool reset_fbo();

        void begin_draw() noexcept;
        void present_only() noexcept;
        void copy_to_renderer_and_present();
        void copy_to_renderer(const rect &dest_rect = {});
        void copy_to_renderer(const rect &src_rect, const rect &dest_rect);
        void copy_from(proxy_renderer &rend, const rect &dest_rect = {});
        void copy_from(proxy_renderer &rend, const rect &src_rect, const rect &dest_rect);

        void clear(const color &color = {}) noexcept;

        int get_width() const;
        int get_height() const;

        bool draw_cmd_list(const draw_list &list) const noexcept;

        const rect& get_rect() const;

        bool enable_vsync() noexcept;
        bool disable_vsync() noexcept;

        inline renderer& get_renderer() { return rend_; }
        bool is_with_fbo() { return !!fbo_; }
        void resize_fbo(int fbo_w, int fbo_h);
        texture_ptr get_fbo() const { return fbo_; }
    private:

        renderer& rend_;
        texture_ptr fbo_;
        bool force_fbo_ {false};
        bool blur_fbo_ {false};
    };

}
