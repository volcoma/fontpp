#include "cursor.h"

#include <SDL2/SDL_mouse.h>
#include <map>

namespace video_ctrl
{
    namespace
    {
        SDL_SystemCursor convert_to_sdl_type(video_ctrl::cursor::type t)
        {
            static const std::map<video_ctrl::cursor::type, SDL_SystemCursor> mapping =
            {
                {cursor::type::arrow, SDL_SYSTEM_CURSOR_ARROW},
                {cursor::type::ibeam, SDL_SYSTEM_CURSOR_IBEAM},
                {cursor::type::wait, SDL_SYSTEM_CURSOR_WAIT},
                {cursor::type::crosshair, SDL_SYSTEM_CURSOR_CROSSHAIR},
                {cursor::type::wait_arrow, SDL_SYSTEM_CURSOR_WAITARROW},
                {cursor::type::size_nw_se, SDL_SYSTEM_CURSOR_SIZENWSE},
                {cursor::type::size_ne_sw, SDL_SYSTEM_CURSOR_SIZENESW},
                {cursor::type::size_we, SDL_SYSTEM_CURSOR_SIZEWE},
                {cursor::type::size_ns, SDL_SYSTEM_CURSOR_SIZENS},
                {cursor::type::size_all, SDL_SYSTEM_CURSOR_SIZEALL},
                {cursor::type::no, SDL_SYSTEM_CURSOR_NO},
                {cursor::type::hand, SDL_SYSTEM_CURSOR_HAND}
            };

            const auto find_it = mapping.find(t);
            if (find_it == mapping.cend())
            {
                return SDL_SYSTEM_CURSOR_ARROW;
            }

            return find_it->second;
        }
    }

    cursor::cursor(video_ctrl::cursor::type t)
        :// type_(t),
          cursor_(SDL_CreateSystemCursor(convert_to_sdl_type(t)))
    {

    }

    void cursor::set() const
    {
        if(cursor_)
        {
            SDL_SetCursor(cursor_.get());
        }
    }

    void cursor::cursor_deleter::operator()(SDL_Cursor *&obj) noexcept
    {
        if (obj)
        {
            SDL_FreeCursor(obj);
            obj = nullptr;
        }
    }

}
