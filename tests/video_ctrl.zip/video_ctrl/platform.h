#ifndef VIDEO_CTRL_PLATFORM_H
#define VIDEO_CTRL_PLATFORM_H

#include "events.h"
#include "rect.h"
#include "window.h"
#include <egt_hpp/event.hpp>

#include <exception>

namespace video_ctrl
{
    struct exception : public std::runtime_error
    {
        exception(const std::string &reason);
    };

    namespace platform
    {
        namespace mouse
        {
            enum button
            {
                left,   ///< The left mouse button
                right,  ///< The right mouse button
                middle, ///< The middle (wheel) mouse button
            };

            point get_position();
            point get_position(const window& wnd);
            bool is_button_pressed(button b);
        }

        bool init();
        bool destroy();

        /* * * * * * * * * * * * *
        *  get_display_count - return number of displaies connected to PC
        *  get_display_rect  - return rect of display in virtual screen
        * * * * * * * * * * * * */
        int get_display_count();
        rect get_display_rect(int display_id);

        std::string get_clipboard_text();
        void set_clipboard_text(const std::string& text);

        // event system
        // for handaled events see events.h file
        bool poll_event(event& e);
        void push_event(const event& e);
        hpp::event<void(const platform::event&)>& event_handler();
    }
}
#endif // VIDEO_CTRL_PLATFORM_H
